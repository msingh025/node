var express = require('express');
var router = express.Router();
var Util = require(global.storage+'/common/Util');
var process = require('process');
/* GET users listing. */
router.get('/', function(req, res, next) {
  // fetch date and display all data
	 console.info(global.storage);
	let loadData =  Util.load('load.json');
	res.json({success:true, data:JSON.parse(loadData)});
});
router.post('/add', function(req, res, next) {
	 let id = req.param('id');
	 let locationName = req.param('locationName');
	  let objectTosave = { 
			  "locationName":locationName,
			  "id":id
			  
	  };
	  let loadData =  Util.write('load.json', objectTosave);
	
	  res.json({
		  success: true,
		  data: objectTosave
	  });
});
module.exports = router;
