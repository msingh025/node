/**
 * http://usejsdoc.org/
 */

$(document).ready(function() {
	 $('#add_driver_action').on('click', function() {
		  $( "#driveradd" ).dialog({
		              modal: true,
		             
		             width: 400,
		            buttons : {
		                Ok: function() {
		                	var params ={
		            				url:"/driver/add",
		            				method:'POST',
		            				data: $('#form_driveradd').serialize(),
		            		};
		                	AjaxData(params, function(params) {
		                		 var ul = $('#add_driver_action').parent().parent();
		                		 console.log(params.data);
		                		 AddHtmlDOM(params.data, ul);
		                	});
		                    $(this).dialog("close"); //closing on Ok click
		                }
		            },

		        });
	 });
	function AddHtmlDOM(row, ul) {
		
		var li = $(document.createElement('li'))
		.data('row', row)
		.attr({
			id:row.id
		});
		var a = $(document.createElement('a'))
		.attr({
			href:"#",
			
		}).text(row.name)
		li.append(a).draggable({
			  revert: true,
		});
		ul.append(li);
	}
function AddHtmlDOMLoad(row, ul) {
	var li = $(document.createElement('li'))
	.data('row', row)
	.attr({
		id:row.id
	}).addClass('dragable_li');
	var a = $(document.createElement('a'))
	.attr({
		href:"#",
	}).text(row.locationName);
	li.append(a).droppable({
	      drop: function( event, ui ) {
	    	var row1 = $(ui.draggable).data('row');
	    	 
	    	var row2 =  $(this).data('row');
	    	 if(row1.currentLocation == row2.locationName){
	          $( this )
	            .addClass( "ui-state-highlight" );
	    	 } else {
	    		 alert('Load is not suitable for driver');
	    	 }
	        }
	      });
	ul.append(li);
	}
$('#addLoadAction').on('click', function() {
	 $( "#loadAdd" ).dialog({
         modal: true,
         width: 400,
        buttons : {
            Ok: function() {
            	var params ={
        				url:"/load/add",
        				method:'POST',
        				data: {id:$('#load_id').val(), locationName: $('#load_loc').val()}
        		};
            	AjaxData(params, function(params) {
            		 var ul = $('#addLoadAction').parent().parent();
            		 console.log(params.data);
            		 AddHtmlDOMLoad(params.data, ul);
            	});
            	 $(this).dialog("close"); //closing on Ok click
            }
        },

    }	  
);

});
  function LoadPanel() {
	  var params ={
				url:"/load",
				method:'GET'
		};
	  AjaxData(params, function(rows) {
		   var ul = $('#addLoadAction').parent().parent();
			if(rows.success && rows.data.length >=0){
				rows.data.forEach(function(row, i){
					AddHtmlDOMLoad(row, ul);
					
				});
			}
			
		});
  }
function DriverPanel() {
	var params ={
			url:"/driver",
			method:'GET'
	}
	AjaxData(params, function(rows) {
		   var ul = $('#add_driver_action').parent().parent();
			if(rows.success && rows.data.length >=0){
				rows.data.forEach(function(row, i){
					AddHtmlDOM(row, ul);
				});
			}
		});
  }

  function AjaxData(params, cb) {
	  $.ajax({
		  url: params.url,
		  type:params.method,
		  data:params.data,
		  success: function(result){
			cb.call(this, result);
	    }});
  }
  LoadPanel();
  DriverPanel();
  
  $( "#droppable" ).droppable({
      drop: function( event, ui ) {
        $( this )
          .addClass( "ui-state-highlight" )
          .find( "p" )
            .html( "Dropped!" );
      }
    });
  $( ".dragable_li" ).draggable();
});