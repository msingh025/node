var express = require('express');
var router = express.Router();
var Util = require(global.storage+'/common/Util');
/* GET users listing. */
router.get('/', function(req, res, next) {
	// fetch date and display all data
	 console.info(global.storage);
	let loadData = Util.load("driver.json");//
	res.json({success:true, data:JSON.parse(loadData)});
});

router.post('/add', function(req, res, next) {
	 let id = req.param('id');
	 let driverName = req.param('driverName');
	 let locationName = req.param('locationName');
	 let objectTosave = { 
			  "name":driverName,
				 "id":id,
				 "currentLocation":locationName
	  };
	  console.log(objectTosave);
	  let isWrite =  Util.write('driver.json', objectTosave);
	 // add loads
	  res.json({
		  success: true,
		  data: objectTosave
	  });
});
router.get('/validate', function(req, res, next) {
	  let driverId = req.param('dId');
	  let loadId = req.param('lId');
	  
	  res.send('respond with a resource');
	});
module.exports = router;
