/**
 * http://usejsdoc.org/
 */
var fs = require('fs');
 function Uitl () {
	 
 }
 Uitl.prototype.load = function(fileName) {
	  try{
	  return fs.readFileSync(global.storage+'/'+fileName, 'utf-8');
	  }catch(Ex) {
		  return false;
	  }
	 
 }
Uitl.prototype.write = function(fileName,objectTosave) {
	  var loadData = this.load(fileName);
	  var ObjectData = JSON.parse(loadData);
	  ObjectData.push(objectTosave);
	   console.log(ObjectData);
	   console.log(objectTosave);
	  var stringData =  JSON.stringify(ObjectData);
	
	  fs.writeFileSync(global.storage+'/'+fileName,stringData);
	  return true;
 }
 module.exports = new Uitl();